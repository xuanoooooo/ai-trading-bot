# 🚀 AI多币种投资组合管理系统

DeepSeek AI管理5币种投资组合：BNB、ETH、SOL、XRP、DOGE

## 🎯 核心特性

- **AI投资组合经理**: 自主决策、动态调仓、多空灵活
- **自动止损保护**: 开仓即下止损单到交易所，AI可动态调整
- **客观信息反馈**: 记录止损触发历史，客观告知AI市场事件
- **三周期分析**: 5分钟K线(短期) + 30分钟K线(中期) + 2小时K线(长期趋势) + BTC大盘
- **完整统计**: 分币种+整体 + 持仓同步
- **可视化看板**: Web实时监控(Flask)，直接读取币安API数据

## 📁 项目结构

```
duobizhong/
├── config/coins_config.json      # 币种配置(精度、最小金额)
├── portfolio_manager.py          # 交易主程序
├── portfolio_statistics.py       # 统计模块
├── market_scanner.py             # 市场数据获取
├── start_portfolio.sh            # 启动交易程序
├── portfolio_stats.json          # 统计数据文件
└── keshihua/                     # 可视化看板
    ├── web_app.py                # Flask后端
    ├── templates/index.html      # 前端页面
    ├── static/                   # CSS/JS
    └── start_web.sh              # 启动看板
```

## 🚀 快速启动

### 交易程序

```bash
cd /root/DS/duobizhong
./start_portfolio.sh              # 启动
tmux attach -t portfolio          # 查看
pkill -f portfolio_manager.py     # 停止
```

### 可视化看板

```bash
cd /root/DS/duobizhong/keshihua
./start_web.sh                    # 启动(后台运行)
pkill -f web_app.py               # 停止

# SSH隧道访问(本地安全)
ssh -L 5000:localhost:5000 user@server
# 浏览器: http://localhost:5000
```

## 🎯 AI决策机制

### 系统信息（传递给AI）
```
╔════════════════════════════════════════════════════════════╗
║          📊 AI投资组合管理系统 - 第 120 次调用          ║
╚════════════════════════════════════════════════════════════╝

⚠️ 系统运行状态
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📅 程序启动时间: 2025-10-26 10:00:00
⏰ 当前时间: 2025-10-26 18:00:00
⏱️  本次已运行: 8.0小时 (480分钟)
🔄 本次调用次数: 120 次

📊 数据说明:
⚠️ 所有K线和技术指标数据按时间排列: 最旧 → 最新
⚠️ 指标趋势用箭头(→)连接，显示最近10个值的变化

📈 数据周期:
- 5分钟K线: 短期分析（最近50根 = 4小时，含时间序列）
- 30分钟K线: 中期趋势（最近60根 = 30小时，含时间序列）
- 2小时K线: 长期趋势（最近60根 = 5天，轻量级）
- 指标时间序列: 最近10个值（5分钟 = 50分钟，30分钟 = 5小时）

⏰ AI调用频率:
- 每5分钟调用一次AI进行决策（与5分钟K线周期同步）
- 分析5分钟K线数据（捕捉短期机会，噪音适中）
- 当前K线的数据是动态更新的（反映此时此刻的市场状态）
- 💡 调用间隔可灵活调整：1分钟（激进）→ 5分钟（平衡）→ 10分钟（稳健）
```

### AI身份定位
```
【交易身份】
- 管理类型：多币种投资组合（BNB/ETH/SOL/XRP/DOGE）
- K线数据：5分钟(短期) + 30分钟(中期) + 2小时(长期)
- 调用频率：每5分钟
- 交易方向：做多做空同样积极，不偏好任何方向
- 交易风格：专业日内交易者

【核心目标】
通过专业技术分析，捕捉市场中的超额收益机会（alpha）。
```

### 输入数据（v2.5 优化版）
- **运行状态**: 启动时间、运行时长、调用次数（给AI时间尺度感）
- **统计**: 胜率、各币种表现、最近交易
- **止损触发记录** ⭐新增: 最近30分钟内的止损事件（币种、方向、止损价、持仓时长、盈亏）
- **BTC大盘**:
  - 价格、5m涨跌、资金费率、持仓量
  - 5分钟: RSI/MACD/ATR + 时间序列（最近10个值）
  - 30分钟: RSI/MACD/ATR/SMA20/50 + 时间序列
  - 2小时: RSI/MACD/SMA20/50（轻量级，无时间序列）
- **组合状态**: 总资金、持仓、分币种盈亏(含浮盈浮亏、止损止盈价格)
- **各币种市场数据**:
  - 基础: 价格、24h/5m涨跌、资金费率、持仓量
  - 5分钟: RSI/MACD/ATR/SMA20/50/布林带 + 时间序列（最近10个值）
  - 30分钟: RSI/MACD/ATR/SMA20/50 + 时间序列
  - 2小时: RSI/MACD/SMA20/50（轻量级，无时间序列）
  - K线: 最近50根5分钟K线（OHLCV，约4小时历史）

### AI权限
- ✅ 完全控制所有币种仓位
- ✅ 可开/平/加仓、多空切换
- ✅ 自主决定持仓数量和资金分配

### 交易理念（传递给AI）
- 您是投资组合的唯一决策者
- 根据技术指标、盈亏情况、市场趋势、BTC大盘自主判断
- 基于实际市场波动设定合理预期
- **不做硬编码规则**: 无固定止盈止损要求，让AI基于技术分析自主决策

### 硬性限制
- 单币种无上限 | 现金 ≥ 10%
- 最小金额: BNB 12 | ETH 24 | SOL/XRP/DOGE 6 USDC
- 止损必填: AI每次开仓/HOLD必须给出止损价格（开仓时自动下单到交易所）

### 可用操作
`OPEN_LONG` | `OPEN_SHORT` | `CLOSE` | `ADD` | `HOLD`

### 止损止盈机制 ⭐
- **止损（必须）**: AI给出价格 → 自动在币安下止损单 → 触发自动平仓 → AI知道被止损
- **止盈（建议）**: AI给出价格 → 仅记录 → AI每10分钟自己评估是否平仓
- **动态调整**: AI可在每次决策时修改止损价格（系统自动更新订单）

## 📊 核心设计

### 数据原则
- ✅ **只给客观数据**: 硬性限制+完整数据，不硬编码交易规则和趋势判断
- ✅ **三周期架构**: 5分钟(短期信号) + 30分钟(中期趋势) + 2小时(长期方向) + BTC(大盘)
- ✅ **时间序列**: 给AI展示指标变化趋势（最近10个值），而非单个快照
- ✅ **市场情绪**: 资金费率（多空情绪）+ 持仓量（参与度）
- ✅ **波动率**: ATR指标帮助AI判断市场状态和设置合理止损
- ✅ **自动同步**: 启动时同步币安持仓，以币安为准

### 容错机制
- **智能舍入**: 自动选择floor/ceil使仓位接近目标
- **15%容差**: 允许实际仓位与目标有合理偏差
- **动态精度**: 从币安API查询各币种精度

## 🖥️ 可视化看板

### 功能
- 📊 账户总览: 资金、盈亏(已实现+浮盈浮亏)、胜率、交易数（直接读币安API）
- 🪙 当前持仓: 实时显示5个币种持仓+浮盈浮亏+止损止盈价格（含止损单状态✅）
- 📜 交易历史: 最近15笔交易记录
- 🤖 AI决策日志: 最近10条AI决策及理由
- 📈 盈亏曲线: 累计盈亏趋势图(仅在新交易时更新，避免闪烁)
- 💹 实时价格: 顶部滚动显示BTC/BNB/ETH/SOL/XRP/DOGE价格

### 技术栈
- **后端**: Flask(仅监听localhost，SSH隧道访问)
- **数据源**: 直接读取币安API（账户、持仓）+ 本地文件（止损止盈、交易历史）
- **前端**: Chart.js + 原生JS + 暗色终端主题
- **更新频率**: 10秒(持仓/统计/价格) | 有新交易时(曲线)

## 📝 常用命令

```bash
# 交易程序
tail -f portfolio_manager.log     # 查看日志
tmux attach -t portfolio           # 连接会话
pkill -f portfolio_manager.py      # 停止程序

# 看板
tail -f keshihua/web_app.log       # 查看日志
pkill -f web_app.py                # 停止看板

# 清空统计(重新开始)
cp portfolio_stats.json portfolio_stats_backup_$(date +%Y%m%d_%H%M%S).json
rm portfolio_stats.json

# 🔄 彻底清空所有记录(完全重置)
# 1. 停止所有程序
pkill -f portfolio_manager.py
pkill -f web_app.py

# 2. 删除所有历史记录文件
rm -f ai_decisions.json         # AI决策历史
rm -f portfolio_stats.json      # 持仓和交易统计
rm -f current_runtime.json      # 运行时状态

# 3. 确认币安账户无持仓(可选)
# 手动平仓或确认账户为空

# 4. 重新启动程序
./start_portfolio.sh            # 从零开始
```

## 🐛 常见问题

### 持仓不同步
启动时自动同步，以币安为准。详见 `持仓同步说明.md`

### 看板显示"加载失败"
检查：1) Web服务是否运行 2) 重启: `pkill -f web_app.py && cd keshihua && ./start_web.sh`

### 盈亏曲线闪烁
已优化：仅在新交易时更新，不再每5秒刷新

### 精度错误/数量计算异常
- 智能舍入：自动选择floor/ceil
- 15%容差：允许合理偏差
- 动态精度：从币安API获取

## 📝 重要文件说明

- `portfolio_stats.json`: 统计数据(含止损触发历史，保留7天)
- `ai_decisions.json`: AI决策日志(看板读取)
- `coins_config.json`: 币种配置(精度、最小金额)
- `持仓同步说明.md`: 同步机制详解
- `快速开始交易程序.md`: 启动/停止命令
- `keshihua/快速开始看板.md`: 看板命令
- `keshihua/SSH隧道使用说明.md`: 安全访问方法

### portfolio_stats.json 数据结构
```json
{
  "trade_history": [...],           // 交易历史
  "stop_loss_history": [            // 止损触发历史（新增）
    {
      "timestamp": "2025-10-29T14:49:09",
      "coin": "BNB",
      "side": "short",
      "entry_price": 1117.65,
      "stop_price": 1120.0,
      "pnl": -1.88,
      "duration_minutes": 3
    }
  ],
  "current_positions": {...}        // 当前持仓（含stop_order_id）
}
```

## 📦 服务器迁移指南

### 🎯 迁移前检查清单

**当前服务器操作**：
```bash
# 1. 停止所有运行程序
pkill -f portfolio_manager.py
pkill -f web_app.py

# 2. 备份重要数据（可选，如果想保留历史）
cd /root/DS/duobizhong
tar -czf backup_$(date +%Y%m%d_%H%M%S).tar.gz \
  portfolio_stats.json \
  ai_decisions.json \
  current_runtime.json \
  portfolio_manager.log \
  .env

# 3. 打包整个项目
cd /root/DS
tar -czf duobizhong_migration.tar.gz duobizhong/

# 4. 下载到本地
# scp root@old-server:/root/DS/duobizhong_migration.tar.gz ./
```

---

### 🚀 新服务器部署步骤

#### 1️⃣ **系统环境准备**

**必须的系统工具**：
- `python3` & `python3-pip` - Python运行环境
- `tmux` - 终端复用器（必须，用于后台运行交易程序）
- `git` - 版本控制（可选）

```bash
# 更新系统（Ubuntu/Debian）
apt update && apt upgrade -y

# 安装必要工具（tmux 必须安装）
apt install -y python3 python3-pip tmux git

# 验证 tmux 安装
tmux -V

# 安装Python依赖（推荐全局安装，无需虚拟环境）
pip3 install python-binance openai python-dotenv schedule pandas flask flask-cors

# 验证Python依赖安装
python3 -c "import binance; import openai; import dotenv; print('✅ 依赖安装成功')"
```

#### 2️⃣ **上传并解压项目**
```bash
# 上传文件到新服务器
# scp duobizhong_migration.tar.gz root@new-server:/root/

# 解压项目
cd /root
mkdir -p DS
cd DS
tar -xzf ../duobizhong_migration.tar.gz

# 确认文件完整性
ls -lh duobizhong/
```

#### 3️⃣ **配置环境变量**
```bash
cd /root/DS/duobizhong

# 创建或编辑 .env 文件
vim .env
```

**必填配置**：
```bash
# 币安API（必须）
BINANCE_API_KEY=your_binance_api_key
BINANCE_SECRET=your_binance_secret

# DeepSeek API（必须）
DEEPSEEK_API_KEY=sk-your-deepseek-api-key
DEEPSEEK_BASE_URL=https://api.deepseek.com
```

**验证配置**：
```bash
# 测试币安API连接
python3 << 'EOF'
import os
from binance.client import Client
from dotenv import load_dotenv

load_dotenv('/root/DS/duobizhong/.env')
client = Client(os.getenv('BINANCE_API_KEY'), os.getenv('BINANCE_SECRET'))
ticker = client.futures_ticker(symbol='BTCUSDT')
print(f"✅ 币安API连接成功！BTC价格: ${float(ticker['lastPrice']):,.2f}")
EOF
```

#### 4️⃣ **启动脚本权限**
```bash
cd /root/DS/duobizhong
chmod +x start_portfolio.sh

cd keshihua
chmod +x start_web.sh
```

#### 5️⃣ **决定是否清空历史记录**

**选项A：全新开始（推荐）**
```bash
cd /root/DS/duobizhong
rm -f ai_decisions.json portfolio_stats.json current_runtime.json
# 程序启动时会自动创建新文件
```

**选项B：保留历史数据**
```bash
# 保持解压后的文件不动即可
# 程序会继续累积统计
```

#### 6️⃣ **启动程序**
```bash
# 启动交易程序
cd /root/DS/duobizhong
./start_portfolio.sh

# 查看启动日志（前30行）
tmux attach -t portfolio

# 启动Web看板（可选）
cd /root/DS/duobizhong/keshihua
./start_web.sh
```

---

### 🔍 **验证部署成功**

```bash
# 1. 检查交易程序是否运行
ps aux | grep portfolio_manager.py

# 2. 检查日志是否正常
tail -20 /root/DS/duobizhong/portfolio_manager.log

# 3. 检查是否能获取市场数据
grep "扫描市场数据" /root/DS/duobizhong/portfolio_manager.log

# 4. 检查AI是否正常调用
grep "AI决策" /root/DS/duobizhong/portfolio_manager.log
```

---

### ⚙️ **关键配置文件位置**

| 文件 | 路径 | 作用 | 是否需要备份 |
|------|------|------|-------------|
| `.env` | `/root/DS/duobizhong/.env` | API密钥配置 | ✅ **必须** |
| `coins_config.json` | `/root/DS/duobizhong/config/` | 币种交易参数 | ✅ 推荐 |
| `portfolio_stats.json` | `/root/DS/duobizhong/` | 历史统计数据 | 📊 可选 |
| `ai_decisions.json` | `/root/DS/duobizhong/` | AI决策日志 | 📊 可选 |
| `portfolio_manager.py` | `/root/DS/duobizhong/` | 主程序 | ✅ **必须** |
| `market_scanner.py` | `/root/DS/duobizhong/` | 市场数据模块 | ✅ **必须** |
| `web_app.py` | `/root/DS/duobizhong/keshihua/` | 可视化看板 | ✅ **必须** |

---

### 🧠 **AI助手快速上手指南**

当你协助新服务器部署时，关键信息：

1. **项目架构**：
   - 主程序：`portfolio_manager.py`（10分钟调用一次AI，可灵活调整）
   - 数据模块：`market_scanner.py`（获取K线+技术指标）
   - 统计模块：`portfolio_statistics.py`（跟踪盈亏）
   - Web看板：`keshihua/web_app.py`（Flask可视化）

2. **系统依赖**（必须）：
   ```bash
   # tmux - 终端复用器（必须，用于后台运行）
   apt install -y tmux
   
   # Python依赖库（无需虚拟环境）
   pip3 install python-binance openai python-dotenv schedule pandas flask flask-cors
   ```

3. **必须配置**：
   - `.env` 文件中的 `BINANCE_API_KEY`、`BINANCE_SECRET`、`DEEPSEEK_API_KEY`
   - 确保 `.env` 路径是 `/root/DS/duobizhong/.env`

4. **核心设计**：
   - 调用频率：每5分钟（可修改 `check_interval_minutes`）
   - 三周期分析：5分钟(短期) + 30分钟(中期) + 2小时(长期)
   - AI完全自主决策，无硬编码规则
   - 使用币安原生库 `python-binance`（非CCXT）
   - 3倍杠杆，管理5个币种：BNB/ETH/SOL/XRP/DOGE

5. **常见问题排查**：
   - API连接失败 → 检查 `.env` 配置和网络
   - 持仓不同步 → 启动时自动同步，以币安为准
   - 看板无数据 → 检查 `web_app.py` 是否运行

6. **快速测试**：
   ```bash
   # 测试币安API
   python3 -c "from binance.client import Client; import os; from dotenv import load_dotenv; load_dotenv('/root/DS/duobizhong/.env'); c = Client(os.getenv('BINANCE_API_KEY'), os.getenv('BINANCE_SECRET')); print(c.futures_ticker(symbol='BTCUSDT')['lastPrice'])"
   ```

---

### 📞 **SSH隧道访问看板**

如果需要从本地浏览器访问Web看板：
```bash
# 本地电脑执行
ssh -L 5000:localhost:5000 root@new-server-ip

# 浏览器访问
http://localhost:5000
```

---

## 🚨 风险提示

加密货币交易高风险，3倍杠杆放大盈亏。建议测试模式先行，持续监控。本项目仅供学习研究，风险自负。

---

## 📜 版本历史

**v2.5.1** (2025-11-01) - 孤儿订单清理机制 🛡️
- ✅ **孤儿订单清理**：防止止损/止盈单在仓位关闭后误触发反向开仓
- ✅ **周期第一步清理**：每个交易周期开始时清理所有孤儿订单
- ✅ **平仓后清理**：AI主动平仓后立即清理该币种所有挂单
- ✅ **单向持仓优化**：针对Binance单向持仓模式进行优化
- 🎯 核心价值：完全杜绝止损触发后止盈单误触发的风险
- 🎯 风控升级：三重保护机制（周期清理 + 平仓清理）

**v2.5.0** (2025-10-29) - 智能止损与学习反馈系统 🎯
- ✅ **自动止损保护**：开仓时立即在币安下止损单（STOP_MARKET），交易所层面硬保护
- ✅ **动态止损调整**：AI每次决策可修改止损价格，自动取消旧单、下新单
- ✅ **止损触发检测**：程序同步时自动查询止损单状态，区分止损触发 vs 手动平仓
- ✅ **客观信息反馈**：记录止损触发历史（保留7天），客观告知AI止损事件（时间、价格、盈亏）
- ✅ **看板数据优化**：改为直接读取币安API，数据100%准确，10秒刷新
- ✅ **价格精度提升**：低价币（DOGE/XRP）显示5位小数，高精度展示价格变化
- 🎯 核心价值：让AI知道市场发生了什么（止损触发事实），帮助AI基于客观数据优化策略
- 🎯 风控升级：止损单在交易所生效，即使程序崩溃也能保护资金

**v2.4.0** (2025-10-28) - 10分钟调用频率优化
- ✅ 调用频率：每10分钟调用AI（平衡及时性与成本）
- ✅ K线数据：仍分析15分钟K线（质量稳定）
- ✅ 动态获取：实时获取最新K线和指标
- ✅ 去除硬编码：只传递客观数据，不指导AI"应该怎么做"

**v2.3.0** (2025-10-27) - 三周期架构
- ✅ 三周期数据：15分钟(短期) + 1小时(中期) + 4小时(长期)
- ✅ 去硬编码判断：删除所有主观趋势判断
- ✅ 完整趋势层次：覆盖4小时→40小时趋势
